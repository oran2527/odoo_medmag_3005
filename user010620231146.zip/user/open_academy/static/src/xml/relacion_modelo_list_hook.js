/** @odoo-module **/

import { useService } from "@web/core/utils/hooks";

const { onWillStart, useComponent } = owl;

export function useBusquedaAudioButton() {
    const component = useComponent();
    const user = useService("user");
    const action = useService("action");

    onWillStart(async () => {
        //component.isSalesManager = await user.hasGroup("sales_team.group_sale_manager");
    });

    component.onClickGenerarBusqueda = () => {

        //alert("iNFORMACION busqueda");  
        action.doAction("open_academy.create_register");

        //const leadType = component.props.context.default_type;

        /*action.doAction({
            name: "Generate Leads",
            type: "ir.actions.act_window",
            res_model: "fv_audios_call_center",
            target: "new",     
            views: [[false, "form"]],
            context: { is_modal: true },
        });*/
    };
}