# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.modules.module import get_module_resource
from odoo.exceptions import ValidationError

from io import BytesIO
from xlrd import open_workbook
import base64
import datetime
import json
import os
import tempfile

class open_academy(models.Model):
    _name = 'open_academy.open_academy'
    _description = 'open_academy.open_academy'

    #campos del archivo plano de medio magnetico segun siesa ver correo
    name = fields.Char(string="Nombre")
    anio = fields.Integer(string="Año")
    formato = fields.Char(string="Formato")
    concepto = fields.Char(string="Concepto")
    tercero = fields.Char(string="Tercero/Nit")
    mandante = fields.Char(string="Mandante")
    fideicomiso = fields.Char(string="Fideicomiso")
    valor1 = fields.Integer(string="Valor1")
    valor2 = fields.Integer(string="Valor2")
    valor3 = fields.Integer(string="Valor3")
    valor4 = fields.Integer(string="Valor4")
    valor5 = fields.Integer(string="Valor5")
    valor6 = fields.Integer(string="Valor6")
    valor7 = fields.Integer(string="Valor7")
    valor8 = fields.Integer(string="Valor8")
    valor9 = fields.Integer(string="Valor9")
    tipo_fideicomiso = fields.Char(string="Tipo Fideicomiso")
    subtipo_fideicomiso = fields.Char(string="Subtipo Fideicomiso")
    valor10 = fields.Integer(string="Valor10")
    valor11 = fields.Integer(string="Valor11")

    #campo para guardar archivo excel
    xls = fields.Binary(string='Archivo', attachment=True, help='Upload the excel file', required=True)

    txt_path = fields.Char(string='Ruta Archivo Texto')
    txt_data = fields.Char(string='Lista Registros')
    """
    @api.depends('value')
    def _value_pc(self):
        for record in self:
            record.value2 = float(record.value) / 100
    """

    #actualiza la informacion del nuevo medio magnetico en la vista principal
    def descargar_archivo_txt(self):
        #traemos la informacion del archivo generado txt en odoo en funcion trans
        base_url, download_url = self.trans()
        
        #retorno al usuario
        return {
            "type": "ir.actions.act_url",
            "url": str(base_url) + str(download_url),
            "target": "new",
        }

    def validar_excel_guardar(self):
        self.trans()
        return {
            'type': 'ir.actions.client',
            'tag': 'reload',
        }

    # metodo para el boton transformar de la vista listado.
    # obtiene el resultado de procesar el excel con las reglas 

    def trans(self):

        #arreglo total que contendra texto por cada final del excel
        txt_data = []

        # ruta para acceder archivo de reglas
        rule_path_json = get_module_resource('open_academy', 'rules', 'reglas.json')        
        
        # extrae informacion del archivo json con las reglas
        with open(rule_path_json) as reglas:
            datos_reglas = json.load(reglas)

        # extraccion en variables de las regla anio
        anio_json_nombre = datos_reglas[0]['nombre']
        anio_json_type = datos_reglas[0]['tipo']
        anio_json_size = int(datos_reglas[0]['TAMANO'])

        # extraccion en variables de las regla formato
        formato_json_nombre = datos_reglas[1]['nombre']
        formato_json_type = datos_reglas[1]['tipo']
        formato_json_size = int(datos_reglas[1]['TAMANO'])

        # extraccion en variables de las regla concepto
        concepto_json_nombre = datos_reglas[2]['nombre']
        concepto_json_type = datos_reglas[2]['tipo']
        concepto_json_size = int(datos_reglas[2]['TAMANO'])

        # extraccion en variables de las regla tercero
        tercero_json_nombre = datos_reglas[3]['nombre']
        tercero_json_type = datos_reglas[3]['tipo']
        tercero_json_size = int(datos_reglas[3]['TAMANO'])

        # extraccion en variables de las regla mandante
        mandante_json_nombre = datos_reglas[4]['nombre']
        mandante_json_type = datos_reglas[4]['tipo']
        mandante_json_size = int(datos_reglas[4]['TAMANO'])

        # extraccion en variables de las regla fideicomiso
        fideicomiso_json_nombre = datos_reglas[5]['nombre']
        fideicomiso_json_type = datos_reglas[5]['tipo']
        fideicomiso_json_size = int(datos_reglas[5]['TAMANO'])

        # extraccion en variables de las regla valor1
        valor1_json_nombre = datos_reglas[6]['nombre']
        valor1_json_type = datos_reglas[6]['tipo']
        valor1_json_size = int(datos_reglas[6]['TAMANO'])

        # extraccion en variables de las regla valor2
        valor2_json_nombre = datos_reglas[7]['nombre']
        valor2_json_type = datos_reglas[7]['tipo']
        valor2_json_size = int(datos_reglas[7]['TAMANO'])

        # extraccion en variables de las regla valor3
        valor3_json_nombre = datos_reglas[8]['nombre']
        valor3_json_type = datos_reglas[8]['tipo']
        valor3_json_size = int(datos_reglas[8]['TAMANO'])

        # extraccion en variables de las regla valor4
        valor4_json_nombre = datos_reglas[9]['nombre']
        valor4_json_type = datos_reglas[9]['tipo']
        valor4_json_size = int(datos_reglas[9]['TAMANO'])

        # extraccion en variables de las regla valor5
        valor5_json_nombre = datos_reglas[10]['nombre']
        valor5_json_type = datos_reglas[10]['tipo']
        valor5_json_size = int(datos_reglas[10]['TAMANO'])

        # extraccion en variables de las regla valor6
        valor6_json_nombre = datos_reglas[11]['nombre']
        valor6_json_type = datos_reglas[11]['tipo']
        valor6_json_size = int(datos_reglas[11]['TAMANO'])

        # extraccion en variables de las regla valor7
        valor7_json_nombre = datos_reglas[12]['nombre']
        valor7_json_type = datos_reglas[12]['tipo']
        valor7_json_size = int(datos_reglas[12]['TAMANO'])

        # extraccion en variables de las regla valor8
        valor8_json_nombre = datos_reglas[13]['nombre']
        valor8_json_type = datos_reglas[13]['tipo']
        valor8_json_size = int(datos_reglas[13]['TAMANO'])

        # extraccion en variables de las regla valor9
        valor9_json_nombre = datos_reglas[14]['nombre']
        valor9_json_type = datos_reglas[14]['tipo']
        valor9_json_size = int(datos_reglas[14]['TAMANO'])

        # extraccion en variables de las regla tipo fideicomiso
        tipo_fideicomiso_json_nombre = datos_reglas[15]['nombre']
        tipo_fideicomiso_json_type = datos_reglas[15]['tipo']
        tipo_fideicomiso_json_size = int(datos_reglas[15]['TAMANO'])

        # extraccion en variables de las regla subtipo fideicomiso
        subtipo_fideicomiso_json_nombre = datos_reglas[16]['nombre']
        subtipo_fideicomiso_json_type = datos_reglas[16]['tipo']
        subtipo_fideicomiso_json_size = int(datos_reglas[16]['TAMANO'])

        # extraccion en variables de las regla valor10
        valor10_json_nombre = datos_reglas[17]['nombre']
        valor10_json_type = datos_reglas[17]['tipo']
        valor10_json_size = int(datos_reglas[17]['TAMANO'])

        # extraccion en variables de las regla valor11
        valor11_json_nombre = datos_reglas[18]['nombre']
        valor11_json_type = datos_reglas[18]['tipo']
        valor11_json_size = int(datos_reglas[18]['TAMANO'])

        #codigo para leer archivo de excel
        for record in self:
            
            # pasos para decodificar archivo de bytes del campo xls        
            inputx = BytesIO()
            inputx.write(base64.decodestring(self.xls))
            book = open_workbook(file_contents=inputx.getvalue())
            
            #acceder a la hoja inicial del archivo de excel
            sh = book.sheet_by_index(0)
            
            #variable cont para evitar la primera fila que son los titulos en bucle for
            cont = True
            
            #contador para determinar la fila del archivo de excel
            cont_valor = 2

            #ingresa fila por fila para verificar cada valor de las celdas anio, concepto y valor
            for rx in range(sh.nrows):
                
                if cont == True:
                    titulo1 = sh.row(rx)[0].value
                    titulo2 = sh.row(rx)[1].value
                    #validacion orden de los titulos del archivo excel fila 1
                    if titulo1.upper() == 'NIT' and titulo2.upper() == 'VALOR':
                        cont = False
                        continue
                    else:
                        # condicion para verificar que el archivo de excel tenga titulos nit y valor en la primera fila
                        cont = False
                        raise ValidationError("El archivo de excel debe tener titulos 'nit' y 'valor' en ese orden en la primera fila")

                #campos del medio magnetico segun archivo word siesa ver correo
                anio_txt = ''
                formato_txt = ''
                concepto_txt = ''
                tercero_txt = ''
                mandante_txt = ''
                fideicomiso_txt = ''
                valor1_txt = ''
                valor2_txt = ''
                valor3_txt = ''
                valor4_txt = ''
                valor5_txt = ''
                valor6_txt = ''
                valor7_txt = ''
                valor8_txt = ''
                valor9_txt = ''
                tipo_fideicomiso_txt = ''
                subtipo_fideicomiso_txt = ''
                valor10_txt = ''
                valor11_txt = ''

                #inicializacion de los campos que aun no estan en vistas. Modificar segun requerimiento
                
                #anio_txt = ''
                self.formato = ''
                #concepto_txt = ''
                self.tercero = ''
                self.mandante = ''
                self.fideicomiso = ''
                #valor1_txt = ''
                self.valor2 = ''
                self.valor3 = ''
                self.valor4 = ''
                self.valor5 = ''
                self.valor6 = ''
                self.valor7 = ''
                self.valor8 = ''
                self.valor9 = ''
                self.tipo_fideicomiso = ''
                self.subtipo_fideicomiso = ''
                self.valor10 = ''
                self.valor11 = ''
                
                #validaciones campos medio magnetico

                
                anio_txt = validations_anio_valor(self.anio, anio_json_type, anio_json_size, anio_json_nombre, cont_valor)
                formato_txt = validations_concepto(self.formato, formato_json_type, formato_json_size, formato_json_nombre, cont_valor)
                concepto_txt = validations_concepto(self.concepto, concepto_json_type, concepto_json_size, concepto_json_nombre, cont_valor)
                tercero_txt = validations_concepto(sh.row(rx)[0].value, tercero_json_type, tercero_json_size, tercero_json_nombre, cont_valor)
                mandante_txt = validations_concepto(self.mandante, mandante_json_type, mandante_json_size, mandante_json_nombre, cont_valor)
                fideicomiso_txt = validations_concepto(self.fideicomiso, fideicomiso_json_type, fideicomiso_json_size, fideicomiso_json_nombre, cont_valor)
                valor1_txt = validations_anio_valor(sh.row(rx)[1].value, valor1_json_type, valor1_json_size, valor1_json_nombre, cont_valor)
                valor2_txt = validations_anio_valor(self.valor2, valor2_json_type, valor2_json_size, valor2_json_nombre, cont_valor)
                valor3_txt = validations_anio_valor(self.valor3, valor3_json_type, valor3_json_size, valor3_json_nombre, cont_valor)
                valor4_txt = validations_anio_valor(self.valor4, valor4_json_type, valor4_json_size, valor4_json_nombre, cont_valor)
                valor5_txt = validations_anio_valor(self.valor5, valor5_json_type, valor5_json_size, valor5_json_nombre, cont_valor)
                valor6_txt = validations_anio_valor(self.valor6, valor6_json_type, valor6_json_size, valor6_json_nombre, cont_valor)
                valor7_txt = validations_anio_valor(self.valor7, valor7_json_type, valor7_json_size, valor7_json_nombre, cont_valor)
                valor8_txt = validations_anio_valor(self.valor8, valor8_json_type, valor8_json_size, valor8_json_nombre, cont_valor)
                valor9_txt = validations_anio_valor(self.valor9, valor9_json_type, valor9_json_size, valor9_json_nombre, cont_valor)
                tipo_fideicomiso_txt = validations_concepto(self.tipo_fideicomiso, tipo_fideicomiso_json_type, tipo_fideicomiso_json_size, tipo_fideicomiso_json_nombre, cont_valor)
                subtipo_fideicomiso_txt = validations_concepto(self.subtipo_fideicomiso, subtipo_fideicomiso_json_type, subtipo_fideicomiso_json_size, subtipo_fideicomiso_json_nombre, cont_valor)
                valor10_txt = validations_anio_valor(self.valor10, valor10_json_type, valor10_json_size, valor10_json_nombre, cont_valor)
                valor11_txt = validations_anio_valor(self.valor11, valor11_json_type, valor11_json_size, valor11_json_nombre, cont_valor)

                #agrega los valores de los campos de la fila del archivo plano
                txt_data.append(anio_txt + concepto_txt + valor1_txt)

                #incrementa el contador de filas del archivo de excel
                cont_valor += 1
        

        # ruta para acceder archivo de texto
        
        current_date = datetime.datetime.now()
        cyear = str(current_date.year) + "_"
        cmonth = str(current_date.month) + "_"
        cday = str(current_date.day) + "_"
        chour = str(current_date.hour) + "_"
        cmin = str(current_date.minute) + "_"
        csec = str(current_date.second) 
        filename = "archivo_final_" + cyear + cmonth + cday + chour + cmin + csec + ".txt"  
        #txt_path = new_path + "/../server/odoo/addons/user/open_academy/static/" + filename
        txt_path = get_module_resource('open_academy', 'static') + '\\' + str(filename)
        
        # se abre archivo txt para escribir la informacion del array
        with open(txt_path, 'wt') as final_text:
            for n in txt_data:
                final_text.write(n + '\n')

        
        
        #leer el archivo de texto para descargar directamente

        #lee el archivo txt 
        output = open(txt_path, "r")

        #base_url consigue la url que usa la aplicacion
        base_url = self.env['ir.config_parameter'].get_param('web.base.url')

        #convierte el archivo en archivo binario 
        result = base64.b64encode((output.read()).encode())
        attachment_obj = self.env['ir.attachment']
        attach_name = '_año_' + str(self.anio) + '_concepto_' + str(self.concepto) + '_fecha_' + cyear + cmonth + cday + '_hora_' + chour + '_minuto_' + cmin + '_segundo_' + csec + ".txt"
        
        #crea el objeto a adjuntar o descargar
        attachment_id = attachment_obj.create(
	        {'name': attach_name, 'datas': result})
        
        #ruta de descarga que maneja odoo
        download_url = '/web/content/' + str(attachment_id.id) + '?download=true'
        
        #retorna base_url y download_url para poder hacer descarga en
        #funcion descargar_archivo_txt
        return base_url, download_url
    
    
        

#funcion para validar las variables anio y valor y para los tipo numerico de las reglas
def validations_anio_valor(value, json_type, json_size, json_nombre, cont_valor):
    if not type(value) == str:
        value = int(value)
    if(str(value) == 'NaN' or str(value) == 'None'):
        return '0' * json_size       
    elif(len(str(value)) < json_size):
        return ('0' * (json_size - len(str(value))) + str(value))
    elif(len(str(value)) > json_size):
        raise ValidationError("El campo " + json_nombre + " tiene una longitud mayor a " + str(json_size) + " caracteres y se encuentra en la linea " + str(cont_valor) + " del archivo de excel o en el formulario de la aplicacion. Por favor verifica el valor de este campo")    
    else:
        return str(value)

#funcion para validar reglas del campo concepto y los tipo alfanumerico de las reglas
def validations_concepto(value, json_type, json_size, json_nombre, cont_valor):
    if not type(value) == str:
        value = int(value)
    if(str(value) == 'NaN' or str(value) == 'None'):
        return '' * json_size        
    elif(len(str(value)) < json_size):
        return (str(value) + ' ' * (json_size - len(str(value))))
    elif(len(str(value)) > json_size):
        raise ValidationError("El campo " + json_nombre + " tiene una longitud mayor a " + str(json_size) + " caracteres y se encuentra en la linea " + str(cont_valor) + " del archivo de excel o en el formulario de la aplicacion. Por favor verifica el valor de este campo")    
    else:
        return str(value)
    

