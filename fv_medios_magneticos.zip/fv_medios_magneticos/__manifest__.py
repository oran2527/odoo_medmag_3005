# -*- coding: utf-8 -*-
{
    'name': "fv_medios_magneticos",    

    'summary': """
        Short (1 phrase/line) summary of the module's purpose, used as
        subtitle on modules listing or apps.openerp.com""",

    'description': """
        Long description of module's purpose
        Fenalco Medios Magneticos - Aplicacion para generar medios magneticos 
    """,

    'author': "My Company",
    'website': "https://www.yourcompany.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/16.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'views/views.xml',
        'wizard/modal_view_form.xml',
        'views/templates.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ], 

    'assets': {
        'web.assets_backend': [
            'fv_medios_magneticos/static/src/js/audio.js',
            'fv_medios_magneticos/static/src/js/audio.xml',  
            'fv_medios_magneticos/static/src/xml/relacion_modelo_list_hook.js',
             
            'fv_medios_magneticos/static/src/xml/relacion_modelo_list_view.js',
            'fv_medios_magneticos/static/src/xml/relacion_modelo_list_view.xml',
            
                   
        ] ,

        'web.assets_common': [
                'fv_medios_magneticos/static/src/js/audioplayer.css',
                'fv_medios_magneticos/static/src/js/audioplayer.js',
        ],
    }
    

    
}
