/** @odoo-module **/

import { registry } from "@web/core/registry";

import { ListController } from "@web/views/list/list_controller";
import { listView } from "@web/views/list/list_view";

import { useBusquedaAudioButton } from "@open_academy/xml/relacion_modelo_list_hook";
   
export class LeadMiningRequestListController extends ListController {
    setup() {
        super.setup();
        useBusquedaAudioButton();
    }
}     

registry.category("views").add("boton_buscar_audio", {
    ...listView,
    Controller: LeadMiningRequestListController,
    buttonTemplate: "LeadMiningRequestListView.buttons",
    //template: "LeadMiningRequestListView.buttons",  
}); 
   
